/*
 * Copyright (C) 2005-2014 Alfresco Software Limited.
 *
 * This file is part of Alfresco
 *
 * Alfresco is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Alfresco is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */
package org.alfresco.web.scripts;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeJSON;
import org.mozilla.javascript.Scriptable;
import org.springframework.extensions.webscripts.processor.JSScriptProcessor;

/**
 * Share JSScript Processor override.
 * <p>
 * Adds the Native JSON implementation from Rhino 1.7R4 into older Rhino versions during scope initialisation
 * 
 * @author Kevin Roast
 */
public class SlingshotJSScriptProcessor extends JSScriptProcessor
{
    @Override
    protected Scriptable initScope(Context cx, boolean secure, boolean sealed)
    {
        Scriptable scope = super.initScope(cx, secure, sealed);
        NativeJSON.init(scope, sealed);
        return scope;
    }
}
