/* Copyright 2004, 2005 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sf.acegisecurity.context.security;

import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.context.ContextImpl;
import net.sf.acegisecurity.context.ContextInvalidException;


/**
 * Basic concrete implementation of a {@link SecureContext}.
 *
 * @author Ben Alex
 * @version $Id: SecureContextImpl.java 644 2005-02-21 06:48:31Z benalex $
 */
public class SecureContextImpl extends ContextImpl implements SecureContext {
    //~ Instance fields ========================================================

    private Authentication authentication;

    //~ Methods ================================================================

    public void setAuthentication(Authentication newAuthentication) {
        this.authentication = newAuthentication;
    }

    public Authentication getAuthentication() {
        return this.authentication;
    }

    public boolean equals(Object obj) {
        if (obj instanceof SecureContextImpl) {
            SecureContextImpl test = (SecureContextImpl) obj;

            if ((this.getAuthentication() == null)
                && (test.getAuthentication() == null)) {
                return true;
            }

            if ((this.getAuthentication() != null)
                && (test.getAuthentication() != null)
                && this.getAuthentication().equals(test.getAuthentication())) {
                return true;
            }
        }

        return false;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(super.toString());

        if (this.authentication == null) {
            sb.append(": Null authentication");
        } else {
            sb.append(": Authentication: " + this.authentication);
        }

        return sb.toString();
    }

    public void validate() throws ContextInvalidException {
        super.validate();

        if (authentication == null) {
            throw new ContextInvalidException("Authentication not set");
        }
    }
}
