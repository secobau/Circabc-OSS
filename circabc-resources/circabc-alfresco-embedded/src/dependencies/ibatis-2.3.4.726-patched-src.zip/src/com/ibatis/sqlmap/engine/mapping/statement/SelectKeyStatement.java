/*
 *  Copyright 2004 Clinton Begin
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * 
 * 2010 - Alfresco Software, Ltd.
 * Alfresco Software has modified source of this file
 * The details of changes as svn diff can be found in svn at location root/projects/3rd-party/src 
 */
package com.ibatis.sqlmap.engine.mapping.statement;

import com.ibatis.common.beans.Probe;
import com.ibatis.common.beans.ProbeFactory;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.event.RowHandler;
import com.ibatis.sqlmap.engine.exchange.DataExchange;
import com.ibatis.sqlmap.engine.mapping.result.ResultMap;
import com.ibatis.sqlmap.engine.mapping.result.ResultMapping;
import com.ibatis.sqlmap.engine.scope.StatementScope;
import com.ibatis.sqlmap.engine.transaction.Transaction;
import com.ibatis.sqlmap.engine.type.TypeHandler;
import com.ibatis.sqlmap.engine.type.TypeHandlerFactory;

import java.beans.BeanDescriptor;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class SelectKeyStatement extends SelectStatement {

  private String keyProperty;
  private boolean runAfterSQL;
  private String generatedKeyColumn;

  public String getKeyProperty() {
    return keyProperty;
  }

  public void setKeyProperty(String keyProperty) {
    this.keyProperty = keyProperty;
  }

  public boolean isRunAfterSQL() {
    return runAfterSQL;
  }

  public void setRunAfterSQL(boolean runAfterSQL) {
    this.runAfterSQL = runAfterSQL;
  }

  public boolean isUseGeneratedKey()
  {
    return generatedKeyColumn != null;
  }
  
  public String getGeneratedKeyColumn()
  {
      return this.generatedKeyColumn;
  }

  public void setGeneratedKeyColumn(String generatedKeyColumn)
  {
    this.generatedKeyColumn = generatedKeyColumn;
  }

  public List executeQueryForList(StatementScope statementScope, Transaction trans, Object parameterObject, int skipResults, int maxResults)
      throws SQLException {
    throw new SQLException("Select Key statements cannot be executed for a list.");
  }

  public void executeQueryWithRowHandler(StatementScope statementScope, Transaction trans, Object parameterObject, RowHandler rowHandler)
      throws SQLException {
    throw new SQLException("Select Key statements cannot be executed with a row handler.");
  }

  @SuppressWarnings("unchecked")
  protected void executeQueryWithCallback(
          StatementScope statementScope, Connection conn, Object parameterObject, Object resultObject,
          RowHandler rowHandler, int skipResults,
          int maxResults) throws SQLException
  {
      if (generatedKeyColumn == null)
      {
        super.executeQueryWithCallback(statementScope, conn, parameterObject, resultObject, rowHandler, skipResults, maxResults);
      }
      else
      {
        // We are using generate keys, so spoof a resultset
        Object generatedKey = GeneratedKeyThreadLocal.getKey();
        if (generatedKey == null)
        {
          throw new SQLException("No generated key value available for column: " + this.generatedKeyColumn);
        }
        // Cast the generated key to the correct type on the resultObject
        ResultMap resultMap = getSql().getResultMap(statementScope, parameterObject);
        Class resultType = resultMap.getResultClass();
        
        if (resultType.isAssignableFrom(generatedKey.getClass()))
        {
          // No conversion required
        }
        else
        {
          // This is untidy, but the type conversion APIs were not designed for this
          TypeHandler resultTypeHandler = new TypeHandlerFactory().getTypeHandler(resultType);
          generatedKey = resultTypeHandler.valueOf(generatedKey.toString());
        }
        rowHandler.handleRow(generatedKey);
      }
  }
  
  public static class GeneratedKeyThreadLocal
  {
      private static final ThreadLocal tl = new ThreadLocal();
      
      public static final Object getKey( )
      {
          return tl.get();
      }

      public static final void setKey(Object key)
      {
          tl.set(key);
      }
      
      public static final void clear( )
      {
          tl.remove();
      }
  }
}
