package com.ibatis.sqlmap.engine.execution;

import com.ibatis.sqlmap.engine.mapping.statement.SelectKeyStatement;

/**
 * This class stores a jdbc3 generated key per thread using a {@link ThreadLocal}. 
 * In this way the key can be passed to lower layers of interfaces without making 
 * any changes to current method signatures.
 *  
 * @see SelectKeyStatement
 */
public class GeneratedKeyThreadLocal
{
	private static final ThreadLocal tl = new ThreadLocal( );
	
	public static final Object getKey( )
	{
		return tl.get( );
	}

	public static final void setKey( Object key )
	{
		tl.set( key );
	}
	
	public static final void clear( )
	{
		tl.remove( );
	}
	
}
