This directory is for utilities used for building / packaging / releasing
ESAPI.

========================

Jim Manico's instructions for creating changelog.txt:

This is an ECLIPSE plug-in feature, not a SVN feature.

I use the SUBCLIPSE plugin.

Right click project root

TEAM -> SHOW HISTORY

Then from the history table, I see a list of history entries that represent
our checking.

I select a few rows, right click, then pick CHANGELOG.


(Note: The SVN Subversive plug-in does NOT support this.)