function testCheckLastTxn()
{
	var indexTxnInfo = admIndexCheckService.checkLastTxn();
}

// Execute test's
testCheckLastTxn();

var result = "";

// return the result message (in this test, empty is success)
result;
