/*
 * Copyright (C) 2005-2011 Alfresco Software Limited.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

 * As a special exception to the terms and conditions of version 2.0 of 
 * the GPL, you may redistribute this Program in connection with Free/Libre 
 * and Open Source Software ("FLOSS") applications as described in Alfresco's 
 * FLOSS exception.  You should have received a copy of the text describing 
 * the FLOSS exception, and it is also available here: 
 * http://www.alfresco.com/legal/licensing"
 */
package org.alfresco.enterprise.repo.bulkimport;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.List;

import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;

import org.alfresco.enterprise.repo.bulkimport.impl.InPlaceNodeImporterFactory;
import org.alfresco.repo.bulkimport.BulkImportParameters;
import org.alfresco.repo.bulkimport.NodeImporter;
import org.alfresco.repo.bulkimport.impl.AbstractBulkImportTests;
import org.alfresco.repo.content.ContentStore;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.util.ApplicationContextHelper;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.util.ResourceUtils;

/**
 * 
 * @since 4.0
 *
 */
public class BulkImportTests extends AbstractBulkImportTests
{
	private InPlaceNodeImporterFactory inPlaceNodeImporterFactory;

	@BeforeClass
	public static void beforeTests()
	{
		startContext(new String[] {"classpath:bulkimporttest/alfresco/overrides-context.xml", ApplicationContextHelper.CONFIG_LOCATIONS[0]});
	}

    @Before
	public void setup() throws SystemException, NotSupportedException
	{
    	super.setup();
    	inPlaceNodeImporterFactory = (InPlaceNodeImporterFactory)ctx.getBean("inPlaceNodeImporterFactory");
	}
		
    /**
     * InPlaceNodeImporter should skip folders if they are described only using metadata file and has no content folder. There should'n be any errors.
     * 
     * @throws Throwable
     */
    @Test
    public void testMNT9851() throws Throwable
    {
        txn = transactionService.getUserTransaction();
        txn.begin();

        NodeRef folderNode = topLevelFolder.getNodeRef();
        File bulkimport4 = ResourceUtils.getFile("classpath:bulkimport4");
        ContentStore fileContentStore = (ContentStore)ctx.getBean("fileContentStore");
        File contentStoreRoot = new File(fileContentStore.getRootLocation());
        FileUtils.copyDirectory(bulkimport4, contentStoreRoot);
        
        try
        {
            NodeImporter nodeImporter = inPlaceNodeImporterFactory.getNodeImporter("default","bulkimport4");
            BulkImportParameters bulkImportParameters = new BulkImportParameters();
            bulkImportParameters.setTarget(folderNode);
            bulkImportParameters.setReplaceExisting(true);
            bulkImportParameters.setDisableRulesService(true);
            bulkImportParameters.setBatchSize(40);
            bulkImporter.bulkImport(bulkImportParameters, nodeImporter);
        }
        catch(Throwable e)
        {
            fail(e.getMessage());
        }

        System.out.println(bulkImporter.getStatus());
        assertEquals(false, bulkImporter.getStatus().inProgress());
        
        List<FileInfo> folders = getFolders(folderNode, null);
        assertEquals(0, folders.size());
    }  

    @Test
    public void testInPlaceImportStriping() throws Throwable
    {
        txn = transactionService.getUserTransaction();
        txn.begin();
        
        NodeRef folderNode = topLevelFolder.getNodeRef();
        File bulkimport5 = ResourceUtils.getFile("classpath:bulkimport5");
        ContentStore fileContentStore = (ContentStore)ctx.getBean("fileContentStore");
        File contentStoreRoot = new File(fileContentStore.getRootLocation());
        FileUtils.copyDirectory(bulkimport5, contentStoreRoot);

        // import with in-place importer
        try
        {
            NodeImporter nodeImporter = inPlaceNodeImporterFactory.getNodeImporter("default", "bulkimport5");
            BulkImportParameters bulkImportParameters = new BulkImportParameters();
            bulkImportParameters.setTarget(folderNode);
            bulkImportParameters.setReplaceExisting(true);
            bulkImportParameters.setBatchSize(40);
            bulkImporter.bulkImport(bulkImportParameters, nodeImporter);
        }
        catch(Throwable e)
        {
            fail(e.getMessage());
        }

        System.out.println(bulkImporter.getStatus());

        checkFiles(folderNode, null, 2, 0,
                new ExpectedFile[]
                {
                },
                new ExpectedFolder[]
                {
                    new ExpectedFolder("1"),
                    new ExpectedFolder("3")
                });

        List<FileInfo> folders = getFolders(folderNode, "1");
        assertEquals("", 1, folders.size());
        NodeRef folder1 = folders.get(0).getNodeRef();
        checkFiles(folder1, null, 1, 0, null,
                new ExpectedFolder[]
                {
                    new ExpectedFolder("18")
                });

        folders = getFolders(folder1, "18");
        assertEquals("", 1, folders.size());
        NodeRef folder18 = folders.get(0).getNodeRef();
        checkFiles(folder18, null, 3, 0,
                new ExpectedFile[]
                {
                },
                new ExpectedFolder[]
                {
                    new ExpectedFolder("1"),
                    new ExpectedFolder("2"),
                    new ExpectedFolder("3")
                });

        folders = getFolders(folder18, "1");
        assertEquals("", 1, folders.size());
        folder1 = folders.get(0).getNodeRef();
        checkFiles(folder1, null, 0, 12,
                new ExpectedFile[]
                {
                    new ExpectedFile("9a61c45b-bb1a-4abd-bdf1-0230bdc647d9.bin", MimetypeMap.MIMETYPE_BINARY),
                    new ExpectedFile("e46c83bc-f396-40d2-80e1-67dbde608344.bin", MimetypeMap.MIMETYPE_BINARY)
                },
                new ExpectedFolder[]
                {
                });
    }
}
