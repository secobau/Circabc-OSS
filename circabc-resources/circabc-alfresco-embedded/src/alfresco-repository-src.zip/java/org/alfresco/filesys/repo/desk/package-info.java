/**
 * Implementation of desk top actions for file system protocols.
 */
@PackageMarker
package org.alfresco.filesys.repo.desk;
import org.alfresco.util.PackageMarker;
