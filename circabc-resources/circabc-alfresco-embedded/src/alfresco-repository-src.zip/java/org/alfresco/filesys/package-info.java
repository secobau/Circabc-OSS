/**
 * The Alfresco file system interface implementation
 */
@PackageMarker
package org.alfresco.filesys;
import org.alfresco.util.PackageMarker;
