//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CAlfrescoApp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CALFRESCOAPP_DIALOG         102
#define IDR_HTML_CALFRESCOAPP_DIALOG    104
#define IDI_ICON1                       133
#define IDD_DIALOG1                     134
#define IDD_FILESTATUS                  134
#define IDC_MSGTEXT                     1001
#define IDC_FILELIST                    1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
